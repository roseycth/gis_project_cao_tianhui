# setup -------------------------------------------------------------------

library(sf)
library(tmap)
library(tidyverse)

source('scripts/source_leed_airbnb.R')


# find closest five airbnb ------------------------------------------------


# Grab the airbnb dataframe's neighbourhood

leed_closest5_updated <- 
  leed_nbhd_sf %>%
  pull(ID) %>% 
  map_dfr(
    ~{
      target_leed <- 
        leed_nbhd_sf %>% 
        filter(ID == .x)
      airbnb_sf %>% 
        filter(neighbourhood == target_leed$neighbourhood) %>% 
        mutate(
          leed_dist = st_distance(., target_leed)) %>% 
        as_tibble() %>% 
        arrange(leed_dist) %>% 
        slice(1:5) %>%
        transmute(
          leed_id = .x,
          airbnb_id = id)
    })


# Leed ID and Airbnb Info -------------------------------------------------
leed_airbnb_info <- 
  leed_closest5_updated %>% 
  left_join(
    airbnb_sf,
    by = c('airbnb_id' = 'id'))
